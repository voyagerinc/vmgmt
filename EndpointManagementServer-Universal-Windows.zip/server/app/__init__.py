"""Management Server application package."""
__version__ = "4.0.0"
