"""Pydantic request/response models (PRD §26 API contract)."""
from __future__ import annotations
from typing import Any, Dict, List, Optional, Set, Tuple

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from .models import (
    AlertSeverity,
    AlertStatus,
    AssetLifecycle,
    CaptureReason,
    DeviceStatus,
    LicenseEdition,
    LicenseStatus,
    LicenseType,
    Role,
)


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True, use_enum_values=True)


# --------------------------------------------------------------- auth
class LoginIn(BaseModel):
    email: str
    password: str
    tenant_id: Optional[str] = None
    mfa_code: Optional[str] = None


class TokenOut(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    role: str
    tenant_id: Optional[str]
    full_name: str


class PasswordChange(BaseModel):
    current_password: str
    new_password: str


# --------------------------------------------------------------- tenants / licenses
class TenantIn(BaseModel):
    company_name: str
    address: Optional[str] = None
    contact_email: Optional[str] = None
    contact_phone: Optional[str] = None
    deployment_model: str = "on_premise"


class TenantOut(ORM):
    id: str
    company_name: str
    status: str
    deployment_model: str
    contact_email: Optional[str] = None
    contact_phone: Optional[str] = None
    evidence_retention_days: int
    event_retention_days: int
    created_at: datetime


class LicenseIn(BaseModel):
    edition: LicenseEdition = LicenseEdition.STANDARD
    license_type: LicenseType = LicenseType.SUBSCRIPTION_MONTHLY
    term_days: int = 365
    max_devices: int = 25
    max_admins: int = 3
    max_storage_mb: int = 10240
    is_demo: bool = False
    features: Dict[str, bool] = Field(default_factory=dict)


class LicenseOut(ORM):
    id: str
    tenant_id: str
    edition: LicenseEdition
    license_type: LicenseType
    status: LicenseStatus
    activated: bool
    start_date: datetime
    expiry_date: datetime
    max_devices: int
    max_admins: int
    max_storage_mb: int
    features: Dict
    is_demo: bool


class LicensePackageOut(BaseModel):
    """What the customer feeds into the Management Server installer."""
    license_id: str
    activation_token: str
    company_name: str
    server_hint: str


class ActivateIn(BaseModel):
    license_id: str
    activation_token: str
    server_id: str


class ProvisionIn(BaseModel):
    """One-shot customer provisioning: company + owner login + license + email."""
    company_name: str
    address: Optional[str] = None
    contact_email: str                      # registered email (receives the license key)
    contact_phone: Optional[str] = None
    deployment_model: str = "on_premise"
    # owner account
    owner_email: Optional[str] = None          # defaults to contact_email
    owner_name: str = "Account Owner"
    owner_password: Optional[str] = None        # auto-generated if omitted
    # license
    edition: LicenseEdition = LicenseEdition.STANDARD
    license_type: LicenseType = LicenseType.SUBSCRIPTION_MONTHLY
    term_days: int = 365
    max_devices: int = 25
    max_admins: int = 3
    is_demo: bool = False
    send_email: bool = True


class ProvisionOut(BaseModel):
    tenant_id: str
    company_name: str
    owner_email: str
    owner_password: Optional[str]              # returned once so the admin can hand it over
    license_id: str
    license_key: str                        # signed activation token
    expiry: datetime
    max_devices: int
    download_url: str                       # GET endpoint for the .lic file
    email_status: str                       # delivered | outbox | skipped


# --------------------------------------------------------------- users
class UserIn(BaseModel):
    email: str
    full_name: str = ""
    password: str
    role: Role = Role.IT_ADMIN


class UserOut(ORM):
    id: str
    email: str
    full_name: str
    role: Role
    is_active: bool
    mfa_enabled: bool
    last_login: Optional[datetime]


# --------------------------------------------------------------- enrollment
class EnrollTokenIn(BaseModel):
    label: str = "default"
    ttl_hours: Optional[int] = None
    max_uses: int = 0


class EnrollTokenOut(ORM):
    id: str
    token: str
    label: str
    expires_at: datetime
    max_uses: int
    uses: int
    revoked: bool


class AgentEnrollIn(BaseModel):
    license_id: str
    enroll_token: str
    machine_uid: str
    hostname: str
    os_name: Optional[str] = None
    os_version: Optional[str] = None
    ip_address: Optional[str] = None
    mac_address: Optional[str] = None
    agent_version: Optional[str] = None
    hardware: Dict[str, Any] = Field(default_factory=dict)


class AgentEnrollOut(BaseModel):
    device_id: str
    device_cert: str
    heartbeat_interval: int
    policy_version: int
    status: str


# --------------------------------------------------------------- devices
class DeviceOut(ORM):
    id: str
    hostname: str
    machine_uid: str
    os_name: Optional[str]
    os_version: Optional[str]
    ip_address: Optional[str]
    mac_address: Optional[str]
    agent_version: Optional[str]
    employee_id: Optional[str]
    department: Optional[str]
    location: Optional[str]
    status: DeviceStatus
    last_seen: Optional[datetime]
    enrolled_at: datetime
    hardware: Dict
    policy_version: int


class DevicePatch(BaseModel):
    employee_id: Optional[str] = None
    department: Optional[str] = None
    location: Optional[str] = None


# --------------------------------------------------------------- heartbeat / telemetry
class SoftwareItem(BaseModel):
    name: str
    publisher: Optional[str] = None
    version: Optional[str] = None
    install_date: Optional[str] = None


class ActivityItem(BaseModel):
    event_type: str
    application: Optional[str] = None
    domain: Optional[str] = None
    title: Optional[str] = None
    category: Optional[str] = None
    duration_seconds: int = 0
    ts: Optional[datetime] = None
    meta: Dict[str, Any] = Field(default_factory=dict)


class HealthItem(BaseModel):
    cpu_percent: Optional[float] = None
    ram_percent: Optional[float] = None
    disk_percent: Optional[float] = None
    net_up_kbps: Optional[float] = None
    net_down_kbps: Optional[float] = None
    battery_percent: Optional[float] = None
    battery_health: Optional[str] = None
    uptime_seconds: Optional[int] = None
    extra: Dict[str, Any] = Field(default_factory=dict)
    ts: Optional[datetime] = None


class FileEventItem(BaseModel):
    action: str
    path: Optional[str] = None
    destination: Optional[str] = None
    extension: Optional[str] = None
    size_bytes: Optional[int] = None
    classification: Optional[str] = None
    ts: Optional[datetime] = None


class HeartbeatIn(BaseModel):
    agent_version: Optional[str] = None
    ip_address: Optional[str] = None
    health: Optional[HealthItem] = None
    activity: List[ActivityItem] = Field(default_factory=list)
    file_events: List[FileEventItem] = Field(default_factory=list)
    software: Optional[List[SoftwareItem]] = None     # full snapshot when present
    policy_version: int = 0


class HeartbeatOut(BaseModel):
    ok: bool = True
    heartbeat_interval: int
    policy_version: int
    policies: Optional[List[Dict]] = None            # pushed when policy_version changed
    collection: Dict = Field(default_factory=dict)  # per-agent data profile (what to collect)
    screenshot_jobs: List[Dict] = Field(default_factory=list)
    remote_sessions: List[Dict] = Field(default_factory=list)
    server_time: datetime


# --------------------------------------------------------------- assets / employees
class EmployeeIn(BaseModel):
    employee_code: str
    name: str
    email: Optional[str] = None
    department: Optional[str] = None
    designation: Optional[str] = None
    location: Optional[str] = None
    manager_id: Optional[str] = None


class EmployeeOut(ORM):
    id: str
    employee_code: str
    name: str
    email: Optional[str]
    department: Optional[str]
    designation: Optional[str]
    location: Optional[str]
    manager_id: Optional[str]
    status: str


class AssetIn(BaseModel):
    asset_tag: str
    category: str = "computer"
    name: str = ""
    serial_no: Optional[str] = None
    model: Optional[str] = None
    device_id: Optional[str] = None
    employee_id: Optional[str] = None
    department: Optional[str] = None
    location: Optional[str] = None
    purchase_date: Optional[datetime] = None
    warranty_expiry: Optional[datetime] = None
    lifecycle: AssetLifecycle = AssetLifecycle.IN_STOCK
    custom_fields: Dict[str, Any] = Field(default_factory=dict)


class AssetOut(ORM):
    id: str
    asset_tag: str
    category: str
    name: str
    serial_no: Optional[str]
    model: Optional[str]
    device_id: Optional[str]
    employee_id: Optional[str]
    department: Optional[str]
    location: Optional[str]
    purchase_date: Optional[datetime]
    warranty_expiry: Optional[datetime]
    lifecycle: AssetLifecycle
    custom_fields: Dict


# --------------------------------------------------------------- policies / alerts
class PolicyIn(BaseModel):
    name: str
    description: Optional[str] = None
    enabled: bool = True
    priority: int = 100
    scope_type: str = "tenant"
    scope_value: Optional[str] = None
    rule: Dict[str, Any] = Field(default_factory=dict)
    effective_from: Optional[datetime] = None
    effective_to: Optional[datetime] = None
    exceptions: List[Any] = Field(default_factory=list)


class PolicyOut(ORM):
    id: str
    name: str
    description: Optional[str]
    enabled: bool
    priority: int
    scope_type: str
    scope_value: Optional[str]
    rule: Dict
    effective_from: Optional[datetime]
    effective_to: Optional[datetime]
    exceptions: List


class AlertOut(ORM):
    id: str
    device_id: Optional[str]
    policy_id: Optional[str]
    rule_name: str
    severity: AlertSeverity
    message: str
    current_value: Optional[str]
    threshold: Optional[str]
    evidence_id: Optional[str]
    status: AlertStatus
    acknowledged_by: Optional[str]
    resolution_note: Optional[str]
    created_at: datetime


class AlertUpdate(BaseModel):
    status: AlertStatus
    resolution_note: Optional[str] = None


# --------------------------------------------------------------- screenshots / remote
class ScreenshotRequestIn(BaseModel):
    device_id: str
    reason: CaptureReason = CaptureReason.MANUAL
    scheduled_for: Optional[datetime] = None


class RemoteRequestIn(BaseModel):
    device_id: str
    consent_mode: str = "silent"          # silent | notify | consent (per company policy)
    duration_minutes: int = 30
    clipboard_allowed: bool = False
    file_transfer_allowed: bool = False
