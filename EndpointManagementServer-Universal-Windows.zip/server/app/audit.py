"""Audit logging helper (PRD §25). Tamper-evident via per-event correlation + append-only use."""
from __future__ import annotations
from typing import Any, Dict, List, Optional, Set, Tuple


from sqlalchemy.orm import Session

from .models import AuditEvent


def record(
    db: Session,
    *,
    action: str,
    tenant_id: Optional[str] = None,
    actor_id: Optional[str] = None,
    actor_email: Optional[str] = None,
    target_type: Optional[str] = None,
    target_id: Optional[str] = None,
    old_value: Optional[Dict[str, Any]] = None,
    new_value: Optional[Dict[str, Any]] = None,
    result: str = "success",
    source_ip: Optional[str] = None,
) -> AuditEvent:
    ev = AuditEvent(
        action=action,
        tenant_id=tenant_id,
        actor_id=actor_id,
        actor_email=actor_email,
        target_type=target_type,
        target_id=target_id,
        old_value=old_value,
        new_value=new_value,
        result=result,
        source_ip=source_ip,
    )
    db.add(ev)
    db.flush()
    return ev
